
<?php session_start(); ?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<link rel="stylesheet" href="">
	<link rel="stylesheet" href="css/main_test.css" type="text/css" />
    <script src="js/fire_menu.js"></script>
</head>
<body>
	<div>
	    <ul>
		    <li>Home</li>
		    <li>News</li>
		    <li>About Us</li>
		    <li>Product</li>
		    <li>Contact</li>
		    <li><?php 
		       	if (isset($_SESSION['username']) && $_SESSION['username']){
		           // echo 'Hi '.$_SESSION['username']."<br/>";
		           echo '<a href="/login/logout.php">Logout</a>';
		       	}
		       	else{
		           header("refresh:0;url=/login");
		       	}
	    	?>
	    	</li>
	    </ul>
	</div>
    <canvas id="panel" width="1000px" height="100px">HTML5 compliant browser required</canvas>
    <img id="image" src="images/bg.jpg"/>
</body>
</html>